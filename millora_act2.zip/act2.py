from PyQt5.QtWidgets import QMainWindow, QApplication, QAction,QLabel,QFileDialog
from PyQt5 import uic
from PyQt5.QtGui import QPixmap
from PIL.ImageQt import ImageQt,Image
import struct
import sys

#Class for PCX Information
class PCX():
  #Function to open and read PCX file
  def open_pcx(self,path):
      with open(f'{path}','rb') as pcx:
          self.manufacturer = struct.unpack('B', pcx.read(1))[0]
          self.ver = struct.unpack('B', pcx.read(1))[0]
          self.encd = struct.unpack('B', pcx.read(1))[0]
          self.bits = struct.unpack('B', pcx.read(1))[0]
          self.xmin = struct.unpack('H', pcx.read(2))[0]
          self.ymin = struct.unpack('H', pcx.read(2))[0]
          self.xmax = struct.unpack('H', pcx.read(2))[0]
          self.ymax = struct.unpack('H', pcx.read(2))[0]
          self.hdpi = struct.unpack('H', pcx.read(2))[0]
          self.vdpi = struct.unpack('H', pcx.read(2))[0]
          pcx.seek(65,0)
          self.planes = struct.unpack('B', pcx.read(1))[0]
          self.bytes = struct.unpack('H', pcx.read(2))[0]
          self.palette= struct.unpack('H', pcx.read(2))[0]
          self.hor_ss = struct.unpack('H', pcx.read(2))[0]
          self.vert_ss = struct.unpack('H', pcx.read(2))[0]


#Class for Main Window
class UI(QMainWindow, PCX):
  def __init__(self):
    #Load the UI from QtDesigner
    super(UI, self).__init__()
    uic.loadUi('viewer.ui', self)
    self.show()
    
    #Declare the objects and find QObjects from UI
    self.button = self.findChild(QAction, 'actionAdd_Image')
    self.label = self.findChild(QLabel, 'image_view')
    self.information = self.findChild(QLabel, 'img_info')
    
    #When self.button is clicked, trigger the function 'add_image()'
    self.button.triggered.connect(self.add_image)
    
  #Function to open a file dialogue and set the selected image to
  #the label using Pixmap
  def add_image(self,s):
    fileopen,_ = QFileDialog.getOpenFileName(self, 'Open file', '/home',"Image files (*.jpg *.gif *.png *.bmp  *.pcx)")
    print(fileopen)
    if(fileopen.endswith('.pcx')):
      self.open_pcx(fileopen)
      self.information.setText(f"Manufacturer: {self.manufacturer} \nVersion: {self.ver} \nEncoding: {self.encd} \nBits per pixel: {self.bits} \nImage Dimensions: {self.xmin} {self.ymin} {self.xmax} {self.ymax} \nHDPI: {self.hdpi} \nVDPI: {self.vdpi} \nNumber of Color Planes: {self.planes} \nBits per Line: {self.bytes} \nPalette Information: {self.palette} \nHorizontal Screen Size: {self.hor_ss} \nVertical Screen Size: {self.vert_ss}")
    else:
      self.information.setText("No Information")
    
    
    img = Image.open(fileopen)
    self.image = ImageQt(fileopen)
    self.pixmap = QPixmap.fromImage(self.image)
    self.label.setPixmap(self.pixmap)

app = QApplication(sys.argv)
UIWindow = UI()
UIWindow.setWindowTitle('Image Viewer')
app.exec_()
    